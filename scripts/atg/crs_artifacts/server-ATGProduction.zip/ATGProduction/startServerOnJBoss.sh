#!/bin/sh
/home/vagrant/jboss//bin/standalone.sh --server-config=ATGProduction.xml $*