#!/bin/sh
/home/vagrant/jboss//bin/standalone.sh --server-config=ATGPublishing.xml $*